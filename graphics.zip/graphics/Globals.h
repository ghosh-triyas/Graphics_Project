#ifndef GLOBALS_H
#define GLOBALS_H

#include <QGraphicsScene>
class MyView;
class Game;
class MyRect;

extern QGraphicsScene* globalscene;
extern MyRect* palete;

#include <QGraphicsTextItem>

extern int globalScore;
extern QGraphicsTextItem* scoreTextItem;

void increaseGlobalScore();

extern int globalHealth;
extern QGraphicsTextItem* healthTextItem;

void decreaseGlobalHealth();

extern Game* globalGame;

void triggerGameOver();

#endif // GLOBALS_H
