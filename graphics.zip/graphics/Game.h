#ifndef GAME_H
#define GAME_H

#include <QGraphicsView>
#include <QWidget>
#include <QGraphicsScene>
#include "MyView.h"
#include <QObject>
#include "Globals.h"

class Game:public QGraphicsView{
    Q_OBJECT
public:
    Game();
    MyView * view;

    void DisplayMainMenu();
    bool inMenuScreen;
    void drawPanel(int x, int y, int height, int width, QColor color, double opactiy);

    void gameover();
    void displayGameOverWindows(QString text);
public slots:
    void start();


};


#endif // GAME_H
