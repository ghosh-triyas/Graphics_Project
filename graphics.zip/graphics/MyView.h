#ifndef MYVIEW_H
#define MYVIEW_H

#include <QGraphicsView>
#include <QMouseEvent>
#include "Globals.h"

class MyView : public QGraphicsView {

public:
    MyView(QGraphicsScene* scene);
    void addpalete();

protected:
    void mouseMoveEvent(QMouseEvent *event) override;


};

#endif
