#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsView>
#include "Ball.h"
#include "MyView.h"
#include <QBrush>
#include <QColor>
#include <QGraphicsEllipseItem>
#include <QPen>
#include <QTimer>
#include "Bricks.h"
#include <QString>
#include <QGraphicsTextItem>
#include <QFont>
#include "Button.h"
#include "MainGame.h"
#include "Game.h"
#include "Globals.h"

extern Game* game;

void createBricks(QGraphicsScene* scene, int offset, const QColor& color) {
    int brickWidth = 30;
    int brickHeight = 15;
    int spacing = 5;

    int rows =1;
    int columns = (800+spacing)/(brickWidth+spacing);

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < columns; ++j) {
            Bricks* brick = new Bricks(color);

            int xPos = j * (brickWidth + spacing);
            int yPos = i * (brickHeight + spacing) + offset;

            brick->setRect(0, 0, brickWidth, brickHeight);
            brick->setPos(xPos, yPos);



            scene->addItem(brick);
        }
    }
}

MainGame::MainGame()
{




    globalscene->setBackgroundBrush(QBrush(Qt::black));




    QColor platecolor = QColor(128, 128, 128);





    palete->setRect(0,0,100,10);
    palete->setBrush(QBrush(platecolor));


    globalscene->addItem(palete);


    game->view->setScene(globalscene);


    game->view->addpalete();


    palete->setPos(game->view->width()/2 - palete->rect().width()/2, game->view->height()-palete->rect().height() -50);

    QColor redbrickColor = QColor(255, 0, 0);
    QColor orangebrickColor = QColor(255, 165, 0);
    QColor yellowbrickColor = QColor(255, 255, 0);
    QColor greenbrickColor = QColor(0, 255, 0);
    QColor bluebrickColor = QColor(0, 0, 255);


    createBricks(globalscene,50,redbrickColor);
    createBricks(globalscene,70,orangebrickColor);
    createBricks(globalscene,90,yellowbrickColor);
    createBricks(globalscene,110,greenbrickColor);
    createBricks(globalscene,130,bluebrickColor);

}








