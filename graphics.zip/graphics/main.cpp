#include <QApplication>

#include "Game.h"
#include "MainGame.h"
#include "Globals.h"
#include "MyRect.h"


MainGame * game1;
Game * game;
QGraphicsScene* globalscene = nullptr;


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    globalscene = new QGraphicsScene();


    scoreTextItem = new QGraphicsTextItem();
    scoreTextItem->setPlainText(QString("Score: 0"));
    scoreTextItem->setDefaultTextColor(Qt::white);
    scoreTextItem->setFont(QFont("Georgia", 20));
    scoreTextItem->setPos(0,0);


    healthTextItem = new QGraphicsTextItem();
    healthTextItem->setPlainText(QString("Health: ") + QString::number(globalHealth));
    healthTextItem->setDefaultTextColor(Qt::red);
    healthTextItem->setFont(QFont("Arial", 16));
    healthTextItem->setPos(0,20);

    palete = new MyRect();



    game = new Game();
    game->DisplayMainMenu();


    return a.exec();
}
