#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsView>
#include "Ball.h"
#include "MyView.h"
#include <QBrush>
#include <QColor>
#include <QGraphicsEllipseItem>
#include <QPen>
#include <QTimer>
#include "Bricks.h"
#include "Game.h"
#include <QString>
#include <QGraphicsTextItem>
#include <QFont>
#include "Button.h"
#include "MainGame.h"
#include <QDebug>
#include <QWidget>
#include "Globals.h"

Game::Game():inMenuScreen(true)
{

    globalGame = this;

    globalscene->setBackgroundBrush(QBrush(Qt::black));





    view = new MyView(globalscene);
    view->setScene(globalscene);

    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setFixedSize(800,600);
    globalscene->setSceneRect(0,0,800,600);





}


void Game::DisplayMainMenu()
{
    QGraphicsTextItem* headline = new QGraphicsTextItem(QString("Let's Play Breakout"));
    QFont headlinefont("Georgia",50);
    headline->setFont(headlinefont);
    headline->setDefaultTextColor(Qt::white);
    headline->setPos(globalscene->width()/2 - headline->boundingRect().width()/2, 150);
    globalscene->addItem(headline);

    Button * startbutton = new Button(QString("START GAME"));
    startbutton->setPos(view->width()/2 - startbutton->boundingRect().width()/2, 275);
    connect(startbutton,SIGNAL(clicked()),this,SLOT(start()));
    globalscene->addItem(startbutton);

    Button * closeGame = new Button(QString("CLOSE"));
    closeGame->setPos(view->width()/2 - closeGame->boundingRect().width()/2, 350);
    connect(closeGame,SIGNAL(clicked()),QApplication::instance(),SLOT(quit()));
    globalscene->addItem(closeGame);

    startbutton->setZValue(1);
    closeGame->setZValue(1);




    view->show();
}

void Game::drawPanel(int x, int y, int width, int height, QColor color, double opactiy)
{
    QGraphicsRectItem * panel = new QGraphicsRectItem(x,y,width,height);
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(color);
    panel->setBrush(brush);
    panel->setOpacity(opactiy);
    globalscene->addItem(panel);
}

void Game::gameover()
{
    if(globalHealth==0)
    {

        QString message;
        message = "YOUR FINAL SCORE IS :" + QString::number(globalScore);
        displayGameOverWindows(message);
    }
}

void Game::displayGameOverWindows(QString text)
{
    for(size_t i=0; i<globalscene->items().size(); i++)
    {
        globalscene->items()[i]->setEnabled(false);
    }

    drawPanel(0,0,800,600,Qt::black,0.90);

    drawPanel(100,100,600,400,Qt::lightGray,0.75);

    inMenuScreen = true;



    Button * quitGame = new Button(QString("QUIT"));
    quitGame->setPos(400 - quitGame->boundingRect().width()/2, 300 - quitGame->boundingRect().height()/2);
    connect(quitGame,SIGNAL(clicked()),QApplication::instance(),SLOT(quit()));
    globalscene->addItem(quitGame);

    QGraphicsTextItem* texttodisplay = new QGraphicsTextItem(text);
    texttodisplay->setPos(300 - texttodisplay->boundingRect().width()/2, 200 - texttodisplay->boundingRect().height()/2);
    QFont newFont("Times New Roman", 30, QFont::Bold, false);  // Example font
    texttodisplay->setFont(newFont);
    texttodisplay->setDefaultTextColor(Qt::yellow);
    globalscene->addItem(texttodisplay);

}

void Game::start()
{

    globalscene->clear();
    globalscene->addItem(scoreTextItem);
    globalscene->addItem(healthTextItem);

    inMenuScreen = false;
    MainGame* maingame = new MainGame();


}








