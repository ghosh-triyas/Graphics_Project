#include "Button.h"
#include <QGraphicsTextItem>
#include <QBrush>
#include <QPointF>
#include <QDebug>
#include "Game.h"
#include <QTimer>

extern Game* game;
Button::Button(QString name, QGraphicsItem *parent):QGraphicsRectItem(parent)
{
    setRect(0,0,200,50);
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::darkCyan);
    setBrush(brush);


    text = new QGraphicsTextItem(name,this);
    text->setPos(rect().width()/2 - text->boundingRect().width()/2, rect().height()/2 - text->boundingRect().height()/2);

    setAcceptHoverEvents(true);
}

void Button::mousePressEvent(QGraphicsSceneMouseEvent* event)
{
    if(game->inMenuScreen)


    {
        qDebug() << "This function is called after a delay 3.";
        QTimer::singleShot(200,this, SLOT(delayedFunction()));
        qDebug() << "This function is called after a delay 4.";


    }

}

void Button::hoverEnterEvent(QGraphicsSceneHoverEvent* event)
{


    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::red);
    setBrush(brush);
  //  QGraphicsRectItem::hoverEnterEvent(event);


}

void Button::hoverLeaveEvent(QGraphicsSceneHoverEvent* event)
{


    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::darkCyan);
    setBrush(brush);
    QGraphicsRectItem::hoverEnterEvent(event);


}

void Button::delayedFunction()
{
     qDebug() << "This function is called after a delay.";
    emit clicked();
}

