QT       += core gui\
         multimedia

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    Ball.cpp \
    Bricks.cpp \
    Button.cpp \
    Game.cpp \
    Globals.cpp \
    MainGame.cpp \
    MyRect.cpp \
    MyView.cpp \
    main.cpp

HEADERS += \
    Ball.h \
    Bricks.h \
    Button.h \
    Game.h \
    Globals.h \
    MainGame.h \
    MyRect.h \
    MyView.h

FORMS +=

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

RESOURCES += \
    resources.qrc \
    sound.qrc
