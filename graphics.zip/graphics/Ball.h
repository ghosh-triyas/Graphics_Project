#ifndef BALL_H
#define BALL_H

#include <QGraphicsEllipseItem>
#include <QBrush>
#include <QPen>
#include <QColor>
#include <QObject>
#include <QGraphicsRectItem>
#include <QMediaPlayer>
#include <QSoundEffect>
#include "Globals.h"
#include "MyRect.h"
#include <QAudioOutput>

class Ball:public QObject, public QGraphicsEllipseItem{
    Q_OBJECT
public:
    Ball();


public slots:
    void move();
    void checkPaleteCollision(MyRect* plate);

private slots:
    void positionChanged(qint64 position);



private:
    double dx;
    double dy;
    QMediaPlayer* player;
    QAudioOutput* audioOutput;


};



#endif
