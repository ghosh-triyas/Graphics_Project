#ifndef MAINGAME_H
#define MAINGAME_H

#include <QGraphicsView>
#include <QWidget>
#include <QGraphicsScene>
#include "MyView.h"
#include <QObject>
#include "Globals.h"
#include <QMediaPlayer>

class MainGame: public QGraphicsView{

public:
    MainGame();

};

#endif // MAINGAME_H
