#include "MyView.h"
#include <QMouseEvent>
#include "Game.h"
#include "Globals.h"
#include "MyRect.h"

extern Game* game;

MyView::MyView(QGraphicsScene *scene):QGraphicsView(scene)
{

}

void MyView::addpalete()
{

    this->setMouseTracking(true);
}

void MyView::mouseMoveEvent(QMouseEvent *event) {
    if(!(game->inMenuScreen)){

    int mouseX = event->pos().x();

    if (mouseX > palete->boundingRect().width()/2 && mouseX < this->width()-palete->boundingRect().width()/2) {
        palete->setPos(mouseX - palete->rect().width() / 2, palete->y());
    }

    }
}
