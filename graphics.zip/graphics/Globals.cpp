#include "globals.h"
#include "Game.h"

int globalScore = 0;
MyRect* palete = nullptr;

QGraphicsTextItem* scoreTextItem = nullptr;

void increaseGlobalScore() {
    globalScore += 1;
    if (scoreTextItem) {
        scoreTextItem->setPlainText(QString("Score: ") + QString::number(globalScore));
    }
}

int globalHealth = 3;
QGraphicsTextItem* healthTextItem = nullptr;

void decreaseGlobalHealth() {
    if (globalHealth > 0) {
        globalHealth--;
        if (healthTextItem) {
            healthTextItem->setPlainText(QString("Health: ") + QString::number(globalHealth));

            if (globalHealth == 0) {
                triggerGameOver();
            }
        }
    }


}

Game* globalGame = nullptr;

void triggerGameOver() {
    if (globalGame) {
        globalGame->gameover();

        globalScore = 0;
        globalHealth = 0;

        // Hide the score and health items from the scene if they exist
        if (scoreTextItem) {
            globalscene->removeItem(scoreTextItem);
        }
        if (healthTextItem) {
            globalscene->removeItem(healthTextItem);
        }
    }
}
