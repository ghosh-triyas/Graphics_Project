#include "Ball.h"
#include <QTimer>
#include <QColor>
#include <qmath.h>
#include <QGraphicsScene>
#include "Bricks.h"
#include <qmath.h>
#include <QtGlobal>
#include <QMediaPlayer>
#include <QDebug>
#include <QSoundEffect>
#include "MainGame.h"
#include "Game.h"
#include "Globals.h"
#include <cmath>
#include <QAudioOutput>


extern MainGame * game;

int flag1 =0;

Ball::Ball()
{
    setRect(0,0,15,15);

    QColor purpleColor = QColor(250, 0, 250);
    QGraphicsEllipseItem::setBrush(QBrush(purpleColor));
    setPen(QPen(Qt::black));

    dx = 10.66;
    dy = -10;

    player = new QMediaPlayer;
    audioOutput = new QAudioOutput;
    player->setAudioOutput(audioOutput);
    connect(player, &QMediaPlayer::positionChanged, this, &Ball::positionChanged);
    player->setSource(QUrl("qrc:/sound/rock_breaking.mp3"));
    audioOutput->setVolume(10);

    QTimer * time = new QTimer();
    connect(time,SIGNAL(timeout()),this,SLOT(move()));


    time->start(50);



}

void Ball::move()
{


    // if(flag1 ==0){
    // int step_size = 10;
    // double theta = rotation();

    // dx = step_size * qCos(qDegreesToRadians(theta));
    // dy = step_size * qSin(qDegreesToRadians(theta));
    // setPos(x() +dx, y()+ dy);

    // }

    setPos(x() +dx, y()+ dy);

    if(pos().x()<=0 || pos().x() + rect().width() >=800)
    {
        dx = -dx;
    }
    if (this->pos().y()<=0)
    {
        dy = -dy;
    }

    QList<QGraphicsItem *> collidingItems = scene()->collidingItems(this);
    for (QGraphicsItem *item : collidingItems) {
        if (MyRect* paleteItem = dynamic_cast<MyRect*>(item)) {
            checkPaleteCollision(qgraphicsitem_cast<MyRect *>(item));
            break;
        }
    }

    if (pos().y() >= 600) {
        setPos(400, 300);
        dx = 10.66;
        dy = -10;


        qreal newWidth = palete->rect().width() - 30;
        qreal height = palete->rect().width();
        if (newWidth > 30) {


            palete->setRect(0,0, newWidth, palete->rect().height());
            // palete->setPos(globalscene->width()/2 - palete->rect().width()/2, globalscene->height()- palete->rect().height() -50);
            globalscene->addItem(palete);

        }
        decreaseGlobalHealth();





    }

    for(int i = 0; i<collidingItems.size(); i++)
    {
        if(typeid(*collidingItems[i])==typeid(Bricks))
        {
            if((collidingItems[i]->x()== (this->x() + rect().width()/2)) && ((collidingItems[i]->x() + collidingItems[i]->boundingRect().width())==(this->x()  - rect().width()/2)))
            {
                dx = -dx;
            }
            else
            {
                dy = -dy;
            }

            increaseGlobalScore();
            if (player->playbackState() == QMediaPlayer::PlayingState) {
                player->setPosition(0);
            } else {
                player->play();
            }

            globalscene->removeItem(collidingItems[i]);
            delete collidingItems[i];

            break;

    }

    }
}

void Ball::checkPaleteCollision(MyRect *paddle)
{
    if (collidesWithItem(paddle)) {
            qreal paddleCenter = paddle->x() + paddle->rect().width() / 2;
            qreal ballCenter = x() + rect().width() / 2;

            qreal difference = ballCenter - paddleCenter;
            qreal normalizedDifference = qAbs(difference / (paddle->rect().width() / 2));

            qreal speed = qSqrt(dx * dx + dy * dy);

            qreal angle;

            if(dx>0)
            {
            angle = normalizedDifference * (90-atan(dy/dx));
            }
            else
            {
                qDebug()<<atan(dy/dx);
            angle = 150 - normalizedDifference * (90+atan(dy/dx));
                qDebug()<<atan(angle);

            }





            qreal angleInRadians = qDegreesToRadians(angle);

            dx = speed * qCos(angleInRadians);
            dy = -speed * qSin(angleInRadians);
        }
}

void Ball::positionChanged(qint64 position)
{
    qDebug() << "Current position:" << position;
}





